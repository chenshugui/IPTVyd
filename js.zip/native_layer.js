
function getParser(url) {
    var parserDef =  JSON.stringify(RootFunction(url));
    console.log("getParser: "+parserDef)
    return parserDef;
}

function getParseResult(methodName, url) {
    console.log("methodName: "+methodName + ", url: " + url);
    var fn = window[methodName];
    var rs = JSON.stringify(fn(url));
    console.log("getParseResult: "+rs);
    return rs;
}

function getStringBtween(str,str1,str2){
	var a = str.substring(str.indexOf(str1)+str1.length);
	a = a.substring(0, a.indexOf(str2));
	return a;
}

function getMD5(str) {
    return client.getMD5(str);
}

function writeFileWithName(fileContent, fileName) {
    return client.writeFile(fileContent, fileName);
}

function getRegex(attributes, pattern) {
    // new RegExp(pattern, attributes);
    var result = attributes.match(pattern);
    console.log("getRegex: " + result);
    return result;
}

function log(content) {
	console.log(content);
}

function AESDecrypt128(content, key) {
    return client.AESDecrypt128(content, key);
}

function encC20Ep(content, key) {
    return client.encC20Ep(content, key);
}

function urlRequest(url) {
    return urlRequestWithPara(url, "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36", "User-Agent");
}

function getUrlContent(url) {
    var header = "{}"
    var content = client.getUrlContent(url, header);
    return content;
}

function urlRequestWithPara(url, headerVal, headerKey) {
    var header = "{'"+headerKey+"':'"+headerVal+"'}";
    var content = client.getUrlContent(url, header);
    return content;
}

function urlRequestWithHeader(url, header) {
    var content = client.getUrlContentWithHeader(url, header);
    return content;
}

//form
function getPostContent(url,post,header) {
    var content = client.getPostContent(url, post, header);
    return content;
}


function getPostContent1(url,post,header,mediaType) {
    var content = client.getPostContent1(url, post, header,mediaType);
    return content;
}


function getLocation(url) {
    var content = client.getLocation(url);
    return content;
}

function urlRequestWithParaAndCoding(url, arr, encode) {
    var header = "{}"
    for (i=0; i<arr.length; i++) {
        header[arr[i].header] = arr[i].value;
    }
    var content = client.getUrlContent(url, header);
    return content;
}


function getNwtime() {
	if(typeof client.getNwtime!='undefined'){
		var content = client.getNwtime();
	}else{
		var content = (Date.parse(new Date()))/1000;
	}
    return content;
}

function getPkgName() {
	if(typeof client.getPkgName!='undefined'){
		var content = client.getPkgName();
	}else{
		var content = "com.jykds.default";
	}
    return content;
}

function getAppVersion() {
	if(typeof client.getAppVersion!='undefined'){
		var content = client.getAppVersion();
	}else{
		var content = "1.0.0";
	}
    return content;
}

function getImei() {
	if(typeof client.getImei!='undefined'){
		var content = client.getImei();
	}else{
		var content = "555555555555555";
	}
    return content;
}

function getMac() {
	if(typeof client.getMac!='undefined'){
		var content = client.getMac();
	}else{
		var content = "00:91:91:91:55";
	}
	if(content=="undefined" || content==""){
		content = "00:91:91:91:55";
	}
    return content;
}

function getPostRespAndHeaders(url,post,headers,mediaType) {
	if(typeof client.getPostRespAndHeaders!='undefined'){
		var content = client.getPostRespAndHeaders(url,post,headers,mediaType);
	}else{
		var content = "undefined";
	}
    return content;
}

function getRespAndHeaders(url,headers) {
	if(typeof client.getRespAndHeaders!='undefined'){
		var content = client.getRespAndHeaders(url,headers);
	}else{
		var content = "undefined";
	}
    return content;
}

function getHost(){
	var app = getPkgName();
	var host = "38.75.136.137:82";
	/*var host = "128.241.228.123:88";//1.1+0.7+0.3+0.4+0.4+0.2+0.2+0.3+0.1+0.2+0.8=4.7w
	if(app=="com.zbdq.tvhd" || app=="com.cjitv.tvhd"|| app=="com.fftv.tvbox"){ //3.6+0.8+0.7=5.1w
		host = "128.241.228.249:88";
	}else if(app=="cc.yftv.tvhd" || app=="com.zstv.tvhd"|| app=="cc.zztv.tvbox"|| app=="com.chenfengtv.tvbox"|| app=="com.pddd.tvhd"){//1.5+1.2+1.5+1.0=5.2w
		host = "128.241.228.100:88";
	}*/
	return host;
}

function getUserToken() {
	if(typeof client.getUserToken!='undefined'){
		var content = client.getUserToken();
	}else{
		var content = "";
	}
	if(content=="undefined" || content==""){
		content = "";
	}
    return content;
}

function getTmKey() {
	if(typeof client.getTmKey!='undefined'){
		var tmKey = client.getTmKey();
	}else{
		var tmKey = "";
	}
	if(tmKey=="undefined" || tmKey==""){
		tmKey = "";
	}
    return tmKey;
}


function replaceAll(string,oldString,newString){
	for(var i=0;i<100;i++){
		if(string.indexOf(oldString)!=-1){
			string=string.replace(oldString,newString);
		}else{
			break;
		}
	}
	return string;
}

function base64decode(str){  
	var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";  
	var base64DecodeChars = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);   
    var c1, c2, c3, c4;  
    var i, len, out;  
    len = str.length;  
    i = 0;  
    out = "";  
    while (i < len) {  
        /* c1 */  
        do {  
            c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff];  
        }  
        while (i < len && c1 == -1);  
        if (c1 == -1)   
            break;  
        /* c2 */  
        do {  
            c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff];  
        }  
        while (i < len && c2 == -1);  
        if (c2 == -1)   
            break;  
        out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));  
        /* c3 */  
        do {  
            c3 = str.charCodeAt(i++) & 0xff;  
            if (c3 == 61)   
                return out;  
            c3 = base64DecodeChars[c3];  
        }  
        while (i < len && c3 == -1);  
        if (c3 == -1)   
            break;  
        out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));  
        /* c4 */  
        do {  
            c4 = str.charCodeAt(i++) & 0xff;  
            if (c4 == 61)   
                return out;  
            c4 = base64DecodeChars[c4];  
        }  
        while (i < len && c4 == -1);  
        if (c4 == -1)   
            break;  
        out += String.fromCharCode(((c3 & 0x03) << 6) | c4);  
    }  
    return out;  
}